#include "db.h"

DB::DB() {
	root = leafHead = new dNode(nullptr); //asuming fresh db

}
void DB::NodeDump(MyStream& outStream)
{
	outStream << "Dump of B+ Tree\n";
	root->NodeDump(0, outStream);
}
void dumpOneLeaf(dNode* leaf, ostringstream& o) {
	for (int i = 0; i < leaf->keysUsed; ++i) 
		o << leaf->data[i].first << " ";
	o << endl;
}
void DB::LeafCheck()
{
	dNode* current;
	dNode* previous = current = static_cast<dNode*>(leafHead);
	int currentVal = current->data->first;
	int i = 1;
	do {
		for (; i < current->keysUsed; ++i) {
			if (current->data[i].first <= currentVal){
				ostringstream oStream;
				oStream << "ERROR: Leaf nodes are not in correct order\n";
				if (previous != current)
					dumpOneLeaf(previous, oStream);
				dumpOneLeaf(current, oStream);
				throw oStream.str();
			}
			currentVal = current->data[i].first;
		}
		i = 0;
		previous = current;
		current = static_cast<dNode*>(current->nextNode);
	} while (current != nullptr);
	
}
void DB::LeafDump(MyStream& outStream) {
	outStream << "Leaves of B+Tree\n";
	dNode* current;
	dNode* next = current = static_cast<dNode*>(leafHead);
	do {
		outStream << "    [ ";
		for (int i = 0; i < current->keysUsed; ++i) {
			outStream << current->data[i].first;
			if (i + 1 != current->keysUsed)
				outStream << ", ";
		}
		outStream << "]";
		if (current->nextNode == nullptr)
			outStream << ".";
		else
			outStream << ",";
		outStream << "\n";
		current = static_cast<dNode*>(current->nextNode);
	} while (current != nullptr);
}
Node* DB::Insert(int key) {
		
	Node* newMaxNode = root->Insert(key);
	if (newMaxNode != nullptr) { //a split has occured
		if (newMaxNode->parent == nullptr) { //root node is a data node.  Must create new iNode
			iNode* newRoot = new iNode(nullptr);
			newMaxNode->parent = root->parent = newRoot;
			newRoot->keys[0] = newMaxNode->GetMinMax();
			newRoot->children[0] = root;
			newRoot->children[1] = newMaxNode;
			newRoot->keysUsed++;
			root = newRoot;

		}
		else { //root node is index node.
			//iNode::HandleSplit(static_cast<iNode*>(root), newMaxNode, key);
		}
			
	}
	return nullptr;
}
bool DB::iNodeTest(int i) {
	return root->iNodeTest(i);
}
void DB::DepthFirstLeafCheck() {
	root->DepthFirstLeafCheck(leafHead->data[0].first - 1);
}