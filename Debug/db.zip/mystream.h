#ifndef MYSTREAM_H
#define MYSTREAM_H
#include <iostream>

class MyStream {
	
	std::ostream& toFile;
	std::ostream& to_cout;
public:
	MyStream(std::ostream& s1, std::ostream& s2);
	template <typename T>
	MyStream& operator<<(T out) {
		toFile << out;
		to_cout << out;
		//toFile.flush();  //performance hit
		return *this;
	}
	operator bool();
	
};

#endif

