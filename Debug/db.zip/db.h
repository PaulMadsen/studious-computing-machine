#ifndef DB_H
#define DB_H

#include "node.h"
#include <sstream>
#include <string>
#include <exception>
#include <iostream>
using std::ostream;
using std::exception;
using std::string;
using std::ostringstream;
class DB {
	Node* root;
	dNode* leafHead;
public:

	DB();
	
	void NodeDump(MyStream& outStream);
	void LeafDump(MyStream& outStream); 
	Node* Insert(int i);
	bool iNodeTest(int i);
	//throws an exception if leaf nodes are not in correct order(ascending).
	void LeafCheck();
	void DepthFirstLeafCheck();
};

#endif
