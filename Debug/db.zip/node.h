#ifndef NODE_H
#define NODE_H
#include <cstddef>
#include <string>
#include <cassert>
#include <iostream>
#include <utility>
#include <sstream>
#include "mystream.h"

using std::ostream;
using std::string;
using std::pair;
using std::cout;
using std::size_t;
using std::endl;

const size_t MAX_INODE_KEYS = 4;
const size_t MIN_INODE_KEYS = MAX_INODE_KEYS / 2;
const size_t MAX_DNODE_KEYS = 4;
const size_t MIN_DNODE_KEYS = MAX_DNODE_KEYS / 2;

class Node {
public:
	virtual Node* Insert(int index) = 0;
	virtual int GetMinMax() = 0;
	Node* parent;
	Node();
	virtual void NodeDump(size_t level, MyStream& out) = 0;
	virtual bool iNodeTest(int i) = 0;
	virtual int DepthFirstLeafCheck(int key) = 0;
	~Node(){ delete parent; }
};

class iNode : public Node{
	int* minMax;
public:
	int keysUsed;
	int keys[MAX_INODE_KEYS];
	Node* children[MAX_INODE_KEYS + 1];

	static Node* Insert(iNode* minNode, Node* maxNode, int index);
	Node* Insert(int key) {
		return Insert(this, nullptr, key);
		
	}
	void NodeDump(size_t level, MyStream& out);
	iNode(Node* parent);
	int GetMinMax();
	bool iNodeTest(int i);
	int DepthFirstLeafCheck(int key);
	~iNode();
};

class dNode : public Node {
	
public:
	
	dNode* nextNode; //linked list
	int keysUsed;
	pair<int, int> data[MAX_DNODE_KEYS];

	dNode(Node* parent);
	Node* Insert(int index);
	//void LeafDump(size_t level, MyStream& out); //handled by DB
	void NodeDump(size_t level, MyStream& out);
	int GetMinMax();
	bool iNodeTest(int i);
	int DepthFirstLeafCheck(int key);
	~dNode();
};
#endif