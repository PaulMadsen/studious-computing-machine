#include <ctime>
#include <memory>
#include <iostream>
#include <map>
#include <limits>
#include <cstdlib>
#include <fstream>
#include "db.h"
#include "node.h"

using std::rand;
using std::srand;
using std::map;
using std::cout;
using std::cin;
using std::endl;


void PrintMenu(MyStream& out) {
	out << "\n0 - Exit" "\n";
	out << "1- Create Tree" "\n";
	out << "2- Auto Create Tree" "\n";
	out << "3- Reset Tree" "\n";
	out << "4- Auto Create Tree in descending order\n";
	out << "5- Random insertion stress test\n";
}

void clear_cin(std::istream& c, MyStream& out) {
	out << "Bad selection" "\n";
	cin.clear();
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

int main() {
	std::ofstream out("log.txt", std::ios::app);
	if (!out)
		cout << "log.txt failed to open\n";
	//out << "output test\n"; //this outputs to disk
	//out.flush();
	MyStream outStream(out, cout);
	if (!outStream)
		cout << "file open failed\n";

	//outStream << "test string\n"; //this outputs to console but not to disk
	std::unique_ptr<DB> db;
	size_t menuChoice = 255;
	PrintMenu(outStream);
	cin >> menuChoice;
	while (menuChoice != 0) {
		if (!cin)
			clear_cin(cin, outStream);
		else if (menuChoice == 1) {
			if (!db)
				db = std::unique_ptr<DB>(new DB());
			int keyToInsert = 0;
			outStream << "Begin inserting keys. -99 to quit\n";
			do {
				if (!(cin >> keyToInsert))
					clear_cin(cin, outStream);
				else {
					db->Insert(keyToInsert);
					db->NodeDump(outStream);
					db->LeafDump(outStream);
				}
			} while (keyToInsert != -99);
		}
		else if (menuChoice == 2) {
			if (!db)
				db = std::unique_ptr<DB>(new DB());
			for (int i = 0; i < 300; i += 10){
				if (i == 240)
				{
					outStream << "";
				}
				outStream << "Inserting " << i << "\n";
				db->Insert(i);
				db->NodeDump(outStream);
				db->LeafDump(outStream);
				if (db->iNodeTest(i) == false) {
					outStream << "\n*** Index " << i << " not found in tree.***\n";
					system("PAUSE");
				}
				try{
					db->LeafCheck();
				}
				catch (exception& e){
					outStream << e.what();
					return -1;
				}
			}
		}
		else if (menuChoice == 3) {
			db = std::unique_ptr<DB>(new DB());
		}
		else if (menuChoice == 4) {
			db = std::unique_ptr<DB>(new DB());
			for (int i = 300; i > 0; i -= 10) {
				if (i == 30)
					outStream << "";
				db->Insert(i);
				db->NodeDump(outStream);
				db->LeafCheck();
				//db->LeafDump();
			}
		}
		else if(menuChoice == 5) {
			
			int toInsert = 0;
			//map<int, int> theMap;
			auto seed = time(NULL);
			while (true) { //run until crash for lack of memory
				srand(seed);
				outStream << "Random seed is " << seed << "\n";
				db = std::unique_ptr<DB>(new DB());
				for (int i = 0; i < RAND_MAX / 2; ++i) {
					toInsert = rand();
					outStream << "Inserting " << toInsert << "\n";
					try {
						db->Insert(toInsert);
						db->NodeDump(outStream);
						db->LeafDump(outStream);
						if (!db->iNodeTest(toInsert)) {
							outStream << "iNodeTest failed\n";
							system("PAUSE");
							db->LeafCheck();
							db->DepthFirstLeafCheck();
						}
					}
					catch (std::bad_alloc& ba) {
						outStream << "bad_alloc caught: " << ba.what() << "\n";
						system("PAUSE");
					}
					catch (string s) {
						outStream << "exception cought...\n";
						outStream << "(string s)\n";
						outStream << s;
						system("PAUSE");
					}
					catch (...) {
						outStream << "exception cought...\n";
						outStream << "default exception catch\n";
						outStream << "Likely a segfault/bad pointer\n";
						system("PAUSE");
					}
				}
			}
		}
		PrintMenu(outStream);
		cin >> menuChoice;
	}
	std::cin.get();
}