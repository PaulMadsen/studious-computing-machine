
#include "node.h"


Node::Node() {
	parent = nullptr;
}
iNode::iNode(Node* parent) : Node(), minMax(nullptr) {
	for (size_t i = 0; i < MAX_INODE_KEYS + 1; ++i)
		children[i] = nullptr;
	keysUsed = 0;
	this->parent = parent;
}
dNode::dNode(Node* parent) : Node() {
	keysUsed = 0;
	nextNode = nullptr;
	this->parent = parent;
}

int dNode::GetMinMax() {
	return data[0].first;
}
ostream& PrintDataNode(dNode* d, ostream& o) {
	o << "( ";
	for (int i = 0; i < d->keysUsed; ++i)
		o << "[" << d->data[i].first << "," << d->data[i].second << "], ";
	o << "]" << endl;
	return o;
}
Node* dNode::Insert(int key) {
	dNode* maxNode = nullptr;
	bool insertSuccess = false;
	//debuging
	//if (key == 19912)//break point
	//	cout << "";
	for (int i = 0; i < keysUsed; ++i) {
		if (data[i].first == key) { return maxNode; }//key already present.  No op
		if (key < data[i].first) {
			if (keysUsed == MAX_DNODE_KEYS) {//leaf node needs to split.  Insertion will be handled by case below
				break;
			}
			int j = 0;
			for (j = keysUsed; j > 0 && data[j - 1].first > key; --j) {//shift right
				data[j].first = data[j - 1].first;
				data[j].second = data[j - 1].second;
			}
			data[j].first = data[j].second = key;
			++keysUsed;
			return maxNode;
		}
	}
	if (keysUsed == 0) { //root case
		data[keysUsed].first = key;
		data[keysUsed++].second = key;
	}

	else if (keysUsed == MAX_DNODE_KEYS) {//split 
		maxNode = new dNode(parent);
		for (size_t i = 0; i < MIN_DNODE_KEYS; ++i) {
			maxNode->data[i] = data[i + MIN_DNODE_KEYS];
		}
		maxNode->keysUsed = keysUsed = MIN_DNODE_KEYS;
		if (key < maxNode->data[0].first) //determine which of the two nodes to insert into
			this->Insert(key);
		else
			maxNode->Insert(key);
		if (nextNode == nullptr)
			nextNode = maxNode;
		else {
			maxNode->nextNode = nextNode;
			nextNode = maxNode;
		}
	}
	else if (data[keysUsed - 1].first < key) { //append to next free space
		data[keysUsed].first = key;
		data[keysUsed++].second = key;
	}

	//PrintDataNode(this);
	return maxNode;
}

//removes and returns the first element of keys and re-arranges keys.
int iNode::GetMinMax() {

	return *minMax;
}
Node* iNode::Insert(iNode* minNode, Node* maxNode, int key) {
	Node* primeNode = nullptr;
	iNode* currentLevelMaxNode = nullptr;
	int i;
	bool insertSuccess = false;
	for (i = 0; i < minNode->keysUsed; ++i) { //find where to insert
		if (key < minNode->keys[i]) {
			primeNode = minNode->children[i]->Insert(key);
			insertSuccess = true;
			break;
		}
		else if (key == minNode->keys[i]) {
			primeNode = minNode->children[i + 1]->Insert(key);
			insertSuccess = true;
			++i; //need this for reordering logic below
			break;
		}
	}
	if (!insertSuccess)  //case key belongs in trailing pointer
		primeNode = minNode->children[minNode->keysUsed]->Insert(key);

	if (primeNode != nullptr) { //split occured below this level
		if (minNode->keysUsed < MAX_INODE_KEYS) { //current iNode has room
			for (int idx = minNode->keysUsed; idx != i; --idx) {
				minNode->keys[idx] = minNode->keys[idx - 1];
				minNode->children[idx + 1] = minNode->children[idx];
			}
			minNode->keys[i] = primeNode->GetMinMax();
			minNode->children[i + 1] = primeNode;
			++(minNode->keysUsed);
		}
		else { //must split this node

			currentLevelMaxNode = new iNode(minNode->parent);
			//if (key == 18716)
			//	cout << "";
			if (key < minNode->keys[MIN_INODE_KEYS - 1]) { //uneven split
				currentLevelMaxNode->minMax = new int(minNode->keys[MIN_INODE_KEYS - 1]); //this is retrieved with getMinMax() by this node's parent
				for (int idx = 0; idx < MIN_INODE_KEYS; ++idx) { //copy keys and pointers to max node
					currentLevelMaxNode->keys[idx] = minNode->keys[idx + MIN_INODE_KEYS];
					currentLevelMaxNode->children[idx] = minNode->children[idx + MIN_INODE_KEYS];
				}
				currentLevelMaxNode->children[MIN_INODE_KEYS] = minNode->children[MAX_INODE_KEYS]; //assign max node trailing pointer

				for (int idx = MIN_INODE_KEYS; idx != i + 1; --idx) { //shift indexes and pointers of min node
					minNode->keys[idx - 1] = minNode->keys[idx - 2];
					minNode->children[idx] = minNode->children[idx - 1];
				}
				minNode->children[i + 1] = primeNode;
				minNode->keys[i] = primeNode->GetMinMax();
			}
			else { //even split
				//if (key == 120)
				//	cout << "";
				currentLevelMaxNode = new iNode(minNode->parent);
				if (i == MIN_INODE_KEYS) { //split occured on the middle pointer.
					currentLevelMaxNode->minMax = new int(primeNode->GetMinMax());
					for (int j = 0; j < MIN_INODE_KEYS; j++) { //copy keys and pointers to the right.
						currentLevelMaxNode->keys[j] = minNode->keys[j + MIN_INODE_KEYS];
						currentLevelMaxNode->children[j + 1] = minNode->children[j + 1 + MIN_INODE_KEYS];
					}
					currentLevelMaxNode->children[0] = primeNode;
				}
				else { //split occured somewhere right of the middle pointer
					currentLevelMaxNode->minMax = new int(minNode->keys[MIN_INODE_KEYS]);
					for (int j = 0; j < MIN_INODE_KEYS - 1; ++j) {//copy keys and pointers right, exclude what would become be the minMax
						currentLevelMaxNode->keys[j] = minNode->keys[j + MIN_INODE_KEYS + 1];
						currentLevelMaxNode->children[j] = minNode->children[j + MIN_INODE_KEYS + 1];
					}
					currentLevelMaxNode->children[MIN_INODE_KEYS-1] = minNode->children[MAX_INODE_KEYS];
					int mm = primeNode->GetMinMax();
					int j = MIN_INODE_KEYS - 1;
					for (; currentLevelMaxNode->keys[j - 1] > mm; --j) { //shift keys and pointers right in order to make room for minmax from lower level
						currentLevelMaxNode->keys[j] = currentLevelMaxNode->keys[j - 1];
						currentLevelMaxNode->children[j + 1] = currentLevelMaxNode->children[j];
					}
					currentLevelMaxNode->keys[j] = primeNode->GetMinMax();
					currentLevelMaxNode->children[j + 1] = primeNode;
				}
			}
			currentLevelMaxNode->keysUsed = minNode->keysUsed = MIN_INODE_KEYS;
		}
	}
	return currentLevelMaxNode;
}


void iNode::NodeDump(size_t level, MyStream& out) {
	string indent(level * 2, ' ');
	out << indent;
	out << "(  *";
	for (int i = 0; i < keysUsed; ++i)
		out << ", " << keys[i] << " *";
	out << ")\n";
	++level;
	for (int i = 0; i < keysUsed; ++i)
		children[i]->NodeDump(level, out);
	children[keysUsed]->NodeDump(level, out);
}

void dNode::NodeDump(size_t level, MyStream& out)
{
	string tabs(level * 2, ' ');
	out << tabs << "[ ";
	for (int i = 0; i < keysUsed; ++i) {
		out << data[i].first;
		if (i != keysUsed - 1)
			out << ", ";
	}
	out << " ]\n";
}

bool iNode::iNodeTest(int i) {
	for (int idx = 0; idx < keysUsed; ++idx) {
		if (i < keys[idx]) {
			return children[idx]->iNodeTest(i);
		}
	}
	return children[keysUsed]->iNodeTest(i);
}
int iNode::DepthFirstLeafCheck(int key)
{
	for (int i = 0; i < keysUsed; ++i) {
		key = children[i]->DepthFirstLeafCheck(key);
	}
	return children[keysUsed]->DepthFirstLeafCheck(key);
}
iNode::~iNode()
{
	delete minMax;
	for (int i = 0; i < keysUsed; ++i)
		delete children[i];
	delete children[keysUsed];
}
bool dNode::iNodeTest(int i) {
	//if (i == 120)
	//	cout << "";
	for (int idx = 0; idx < keysUsed; ++idx) {
		if (i == data[idx].first) {
			return true;
		}
	}
	return false;
}

int dNode::DepthFirstLeafCheck(int key)
{
	for (int i = 0; i < keysUsed; ++i) {
		if (data[i].first < key){
			std::ostringstream err;
			err << "Error: DepthFirstLeafCheck - Leaf nodes are not in order.\n";
			err << "Test key: " << key << ".  Checked against " << data[i].first << "\n";
			PrintDataNode(this, err);
			if (nextNode != nullptr)
				PrintDataNode(nextNode, err);
				
			throw err.str();
		}
		key = data[i].first;
	}
	return key;
}

dNode::~dNode()
{
	//no member variables other than leafHead which would double delete.
}
