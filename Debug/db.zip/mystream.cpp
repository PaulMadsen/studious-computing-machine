#include "mystream.h"

MyStream::MyStream(std::ostream & s1, std::ostream & s2) : toFile(s1), to_cout(s2)
{}

MyStream::operator bool()
{
	return toFile && to_cout;
}



